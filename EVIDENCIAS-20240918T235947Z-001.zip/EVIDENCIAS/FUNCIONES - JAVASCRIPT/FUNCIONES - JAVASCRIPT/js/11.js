function dupicarValores(arr) {
    return arr.map(num => num * 2);
}
console.log("Muestra los valores duplicados de '54,77,21'")
console.log(dupicarValores([54, 77, 21]));