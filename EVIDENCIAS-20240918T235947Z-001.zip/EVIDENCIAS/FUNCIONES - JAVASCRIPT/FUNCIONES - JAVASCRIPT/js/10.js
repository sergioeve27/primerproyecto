function numeroMasPequeno(arr) {
    return Math.min(...arr);
}
console.log("Muestra el numero mas pequeño entre '25, 32, 85, 75'")
console.log(numeroMasPequeno([25, 32, 85, 75]));