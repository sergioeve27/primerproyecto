function mayorDeTres(a,b,c){
    return Math.max(a,b,c);
}
console.log("Muestra el mayor numero entre 8, 12 y 16")
console.log(mayorDeTres(8, 12, 16));