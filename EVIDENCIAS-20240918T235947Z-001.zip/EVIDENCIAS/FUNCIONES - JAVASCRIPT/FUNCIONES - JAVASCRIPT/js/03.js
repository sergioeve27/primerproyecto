function celsiusAFahrenheit(celsius) {
    return (celsius * 9/5) + 32;    
}
console.log("25°C a grados Fahrenheit son")
console.log(celsiusAFahrenheit(25));