function parOImpar(num){
    return num % 2 === 0 ? 'par' : 'impar';
}
console.log("El numero 30 es")
console.log(parOImpar (30));