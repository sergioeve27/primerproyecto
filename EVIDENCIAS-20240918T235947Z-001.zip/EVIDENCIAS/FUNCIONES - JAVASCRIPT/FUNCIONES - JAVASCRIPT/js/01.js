function suma(a, b) {
    return a + b;
}
console.log("Muestra la suma de 5 y 7")
console.log(suma(5, 7)); 
