function revertirCadena(cadena) {
    return cadena.split('').reverse().join('');
}
console.log("Muestra la cadena 'Bastet' invertida")
console.log(revertirCadena("Bastet"));