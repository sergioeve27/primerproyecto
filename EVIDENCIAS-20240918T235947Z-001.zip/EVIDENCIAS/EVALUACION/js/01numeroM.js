function numeroMayor(a,b){
    if (a > b) {
        return a;
    }else{ (a<b)
        return b;
    }

}
console.log("el numero mayor entre 6 y 5 es:")
console.log(numeroMayor(6,5));

function numeroMayor(a,b) {
    return Math.max(a,b);
}
console.log(numeroMayor(5,8))