function sumaDeNumeros(n) {
    let contador = 0;
    for (let i = 0; i <= n; i++) {
       contador += i;
    }
    return contador;
}
console.log("la suma del numero 6 mas los numeros antes de el es igual a:")
console.log(sumaDeNumeros(6));
