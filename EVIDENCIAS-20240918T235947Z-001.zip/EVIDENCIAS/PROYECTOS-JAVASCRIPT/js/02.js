console.log("numeros del 1 al 10");
for (let i = 1; i <= 10; i++) {
    console.log(i);
  }