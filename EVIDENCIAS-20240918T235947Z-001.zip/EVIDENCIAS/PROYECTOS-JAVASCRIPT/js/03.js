console.log("numeros del 10 al 1");
for (let i = 10; i >= 1; i--) {
    console.log(i);
  }