console.log("la tabla de multiplicar del 5")
for (let i = 1; i <= 10; i++) {
    console.log(`5 x ${i} = ${5 * i}`);
  }