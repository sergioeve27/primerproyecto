console.log("Determinar si un número es par o impar")
function isEvenOrOdd(num) {
    if (num % 2 === 0) {
      console.log(`${num} es par.`);
    } else {
      console.log(`${num} es impar.`);
    }
  }