console.log("los números del 1 al 20 hasta que se encuentre el número 15")
for (let i = 1; i <= 20; i++) {
    console.log(i);
    if (i === 15) {
      break;
    }
  }