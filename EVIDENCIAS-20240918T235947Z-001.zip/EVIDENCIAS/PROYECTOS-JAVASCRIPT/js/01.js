let n = 5; // Cambia el valor de 'n' según sea necesario
let resultado;

if (n > 0) {
    resultado = "Positivo";
} else if (n < 0) {
    resultado = "Negativo";
} else {
    resultado = "Cero";
}

console.log("El número es:", n, resultado);
