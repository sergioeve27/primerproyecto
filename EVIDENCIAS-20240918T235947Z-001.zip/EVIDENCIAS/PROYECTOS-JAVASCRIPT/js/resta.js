let w=2, g=3, s=0;

s = w - g;

console.log("La resta es: ", s);
