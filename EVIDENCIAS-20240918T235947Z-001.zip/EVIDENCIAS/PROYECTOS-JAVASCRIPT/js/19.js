console.log("Imprimir los números del 10 al 1 utilizando un ciclo do-while")
let j = 10;
do {
  console.log(j);
  j--;
} while (j >= 1);
