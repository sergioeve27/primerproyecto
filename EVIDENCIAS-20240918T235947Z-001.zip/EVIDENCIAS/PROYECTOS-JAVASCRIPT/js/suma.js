let a=2, b=3, c=0;

c = a + b;

console.log("La suma es: ", c);