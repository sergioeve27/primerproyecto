console.log("Imprimir los números del 1 al 10 utilizando un ciclo while")
let i = 1;
while (i <= 10) {
  console.log(i);
  i++;
}
