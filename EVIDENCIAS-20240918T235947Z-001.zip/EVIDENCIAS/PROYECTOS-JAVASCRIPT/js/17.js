console.log("Imprimir un triángulo de asteriscos de 5 filas")
for (let i = 1; i <= 5; i++) {
    console.log('*'.repeat(i));
  }