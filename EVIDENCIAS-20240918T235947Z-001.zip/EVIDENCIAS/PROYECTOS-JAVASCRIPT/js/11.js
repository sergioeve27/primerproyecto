console.log("los números del 1 al 50 pero saltar los múltiplos de 5")
for (let i = 1; i <= 50; i++) {
    if (i % 5 !== 0) {
      console.log(i);
    }
  }